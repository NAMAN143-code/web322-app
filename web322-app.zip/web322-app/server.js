const express = require("express");
const app = express();
const funcs = require("./blog-service.js")

const HTTP_PORT = process.env.PORT || 8080;


function onHttpStart() {
    console.log("Express http server listening on: " + HTTP_PORT);
}

app.use(express.static('public'));
app.get("/", function(req, res) {
    res.redirect("/about");
});


app.get("/about", function(req, res) {
    res.sendFile(__dirname + "/views/about.html");
});


app.get("/blog", function(req, res) {
    funcs.getPublishedPosts().then((data) => {
        res.send(data)
    }).catch((err) => {
        res.send("unable to load" + err)
    })
})

app.get("/posts", function(req, res) {
    funcs.getAllPosts().then((data) => {
        res.send(data)
    }).catch((err) => {
        res.send("unable to load" + err)
    })
})

app.get("/categories", function(req, res) {
    funcs.getCategories().then((data) => {
        res.send(data)
    }).catch((err) => {
        res.send("unable to load" + err);
    })
})

app.use((req, res) => {
    res.status(404).send("OOps.... Something Went Wrong  ||    404 Not Found");
})

funcs.initialize().then((message) => {
    app.listen(HTTP_PORT, onHttpStart());
}).catch((error) => {
    console.log(error)
})