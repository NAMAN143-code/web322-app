var posts = []
var categories = []
const fs = require('fs');

module.exports.initialize = () => {
    return new Promise((resolve, reject) => {

        fs.readFile('./data/posts.json', 'utf8', (err, posts_data) => {
            if (err) {
                reject("unable to read file");
            } else {
                posts = JSON.parse(posts_data)
                resolve("allocation succeeded")
            }
        })
        fs.readFile('./data/categories.json', 'utf8', (err, categories_data) => {

            if (err) {
                reject("unable to read file");
            } else {
                categories = JSON.parse(categories_data)
                resolve("allocation succeeded")
            }
        })
    })
}

module.exports.getAllPosts = () => {
    return new Promise((resolve, reject) => {
        if (posts == 0) {
            reject('no results returned')
        } else {
            resolve(posts)
        }
    })
}

module.exports.getPublishedPosts = () => {
    return new Promise((resolve, reject) => {
        var published_posts = posts.filter(({ published }) => published === true)
        if (published_posts === 0) {
            reject("no results returned")
        } else {
            resolve(published_posts)
        }
    })
}

module.exports.getCategories = () => {
    return new Promise((resolve, reject) => {
        if (categories === 0) {
            reject("no results returned")
        } else {
            resolve(categories)
        }
    })
}